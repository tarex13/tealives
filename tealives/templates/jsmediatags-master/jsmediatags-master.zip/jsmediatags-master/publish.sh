#!/usr/bin/env bash

npm install
npm run dist
npm run build
npm publish